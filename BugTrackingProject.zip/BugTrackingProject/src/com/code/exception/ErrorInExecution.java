package com.code.exception;

public class ErrorInExecution extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

public ErrorInExecution (String mesg) {
	super(mesg);
}
}
